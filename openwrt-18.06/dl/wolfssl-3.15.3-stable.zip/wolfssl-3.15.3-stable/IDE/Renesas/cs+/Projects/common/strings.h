
int strncasecmp(const char *s1, const char * s2, unsigned int sz);
